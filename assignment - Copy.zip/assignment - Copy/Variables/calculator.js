// Basic Calculator

// Create three variables: num1, num2, and operation (e.g., 'add').
// Write code to perform addition, subtraction, multiplication, or division based on the value of operation.

let num1 = 10;
let num2 = 11;

let sum = num1 + num2;
let subtract = num1 - num2;
let product = num1 * num2;
let division = num1/num2;

console.log("Sum: " + sum);
console.log("Subtract: " + subtract);
console.log("Multiplication: " +product);
console.log("Division: " + division);